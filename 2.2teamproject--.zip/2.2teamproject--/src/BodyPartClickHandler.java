public interface BodyPartClickHandler {

    
    void handleBodyPartClick(String partName);
    
}
